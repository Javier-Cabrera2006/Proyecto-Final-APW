import React, { useEffect, useState } from 'react';
import { Container, Form, Button, Row, Col, Card } from 'react-bootstrap';
import axios from 'axios';

const API = 'http://localhost:5000/api';
const API_KEY = 'my-secret-api-key';

function App() {
  const [tasks, setTasks] = useState([]);
  const [goals, setGoals] = useState([]);
  const [taskTitle, setTaskTitle] = useState('');
  const [goalTitle, setGoalTitle] = useState('');

  const headers = {
    Authorization: API_KEY
  };

  useEffect(() => {
    loadTasks();
    loadGoals();
  }, []);

  const loadTasks = async () => {
    const res = await axios.get(`${API}/getTasks`, { headers });
    setTasks(res.data);
  };

  const loadGoals = async () => {
    const res = await axios.get(`${API}/getGoals`, { headers });
    setGoals(res.data);
  };

  const addTask = async () => {
    await axios.post(`${API}/addTask`,
      { title: taskTitle },
      { headers }
    );
    setTaskTitle('');
    loadTasks();
  };

  const addGoal = async () => {
    await axios.post(`${API}/addGoal`,
      { title: goalTitle },
      { headers }
    );
    setGoalTitle('');
    loadGoals();
  };

  const removeTask = async (id) => {
    await axios.delete(`${API}/removeTask/${id}`, { headers });
    loadTasks();
  };

  const removeGoal = async (id) => {
    await axios.delete(`${API}/removeGoal/${id}`, { headers });
    loadGoals();
  };

  return (
    <Container className="mt-5">
      <h1 className="text-center mb-4">To Do List - Metas y Tareas</h1>

      <Row>
        <Col md={6}>
          <Card className="p-3 shadow">
            <h3>Tareas</h3>

            <Form.Control
              className="mb-2"
              placeholder="Nueva tarea"
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
            />

            <Button onClick={addTask}>Agregar Tarea</Button>

            <ul className="mt-3">
              {tasks.map(task => (
                <li key={task._id}>
                  {task.title}
                  <Button
                    variant="danger"
                    size="sm"
                    className="ms-2"
                    onClick={() => removeTask(task._id)}
                  >
                    Eliminar
                  </Button>
                </li>
              ))}
            </ul>
          </Card>
        </Col>

        <Col md={6}>
          <Card className="p-3 shadow">
            <h3>Metas</h3>

            <Form.Control
              className="mb-2"
              placeholder="Nueva meta"
              value={goalTitle}
              onChange={(e) => setGoalTitle(e.target.value)}
            />

            <Button onClick={addGoal}>Agregar Meta</Button>

            <ul className="mt-3">
              {goals.map(goal => (
                <li key={goal._id}>
                  {goal.title}
                  <Button
                    variant="danger"
                    size="sm"
                    className="ms-2"
                    onClick={() => removeGoal(goal._id)}
                  >
                    Eliminar
                  </Button>
                </li>
              ))}
            </ul>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default App;