const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const Task = require('./models/Task');
const Goal = require('./models/Goal');

const app = express();

app.use(cors());
app.use(express.json());

const API_KEY = 'my-secret-api-key';

app.use((req, res, next) => {
  const auth = req.headers.authorization;

  if(auth !== API_KEY){
    return res.status(401).json({ message: 'Unauthorized' });
  }

  next();
});

mongoose.connect('mongodb://127.0.0.1:27017/todoGoals');

app.get('/api/getTasks', async (req, res) => {
  const tasks = await Task.find();
  res.json(tasks);
});

app.get('/api/getGoals', async (req, res) => {
  const goals = await Goal.find();
  res.json(goals);
});

app.post('/api/addTask', async (req, res) => {
  const task = new Task(req.body);
  await task.save();
  res.json(task);
});

app.post('/api/addGoal', async (req, res) => {
  const goal = new Goal(req.body);
  await goal.save();
  res.json(goal);
});

app.delete('/api/removeTask/:id', async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  res.json({ message: 'Task deleted' });
});

app.delete('/api/removeGoal/:id', async (req, res) => {
  await Goal.findByIdAndDelete(req.params.id);
  res.json({ message: 'Goal deleted' });
});

app.listen(5000, () => {
  console.log('Server running on port 5000');
});