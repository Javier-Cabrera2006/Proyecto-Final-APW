# Backend - To Do List API

## Instalación

npm install

## Ejecutar

npm start

## Endpoints

GET /api/getTasks
GET /api/getGoals
POST /api/addTask
POST /api/addGoal
DELETE /api/removeTask/:id
DELETE /api/removeGoal/:id