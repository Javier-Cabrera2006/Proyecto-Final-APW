const mongoose = require('mongoose');

const GoalSchema = new mongoose.Schema({
  title: String
});

module.exports = mongoose.model('Goal', GoalSchema);